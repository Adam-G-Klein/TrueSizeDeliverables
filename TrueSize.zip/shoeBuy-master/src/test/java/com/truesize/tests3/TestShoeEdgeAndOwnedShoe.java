package com.truesize.tests3;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestDirectedShoeEdge.class , TestOwnedShoe.class})
public class TestShoeEdgeAndOwnedShoe{


}
