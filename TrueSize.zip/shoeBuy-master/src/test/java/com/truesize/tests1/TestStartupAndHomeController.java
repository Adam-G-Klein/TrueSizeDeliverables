package com.truesize.tests1;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestHomeController.class , TestWebApplicationStartup.class})
public class TestStartupAndHomeController{


}
