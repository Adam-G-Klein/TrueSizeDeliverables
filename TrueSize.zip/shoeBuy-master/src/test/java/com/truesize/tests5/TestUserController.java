package com.truesize.tests5;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestAddShoe.class , TestGetUserInfo.class})
public class TestUserController {
}