package com.truesize.tests2;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestShoeSearchFactory.class , TestShoeRecommendLoops.class})
public class TestShoeRecommendAndShoeSearch{


}
