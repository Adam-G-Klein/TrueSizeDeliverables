package com.truesize;

public class StringResponse {
    private String response;

    public StringResponse(String given){
        this.response = given;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
