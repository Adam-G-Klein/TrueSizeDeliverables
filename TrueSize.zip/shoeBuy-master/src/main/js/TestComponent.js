import React from 'react';

class TestComponent extends React.Component {
	render() {
		return (
		    <div>
		    <h1> This is a test! </h1>
		    <marquee> Testing Testing 1 2 3... </marquee>
		    </div>
		)
	}
}

export default TestComponent;